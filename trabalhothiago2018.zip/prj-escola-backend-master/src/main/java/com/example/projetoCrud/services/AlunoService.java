package com.example.projetoCrud.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.projetoCrud.domain.Aluno;
import com.example.projetoCrud.domain.Curso;
import com.example.projetoCrud.dto.AlunoDTO;
import com.example.projetoCrud.repositories.AlunoRepository;
import com.example.projetoCrud.repositories.CursoRepository;

@Service
public class AlunoService {

	@Autowired
	AlunoRepository repositorio;

	@Autowired
	CursoRepository cursoRepositorio;

	public Aluno find(Integer id) {

		Aluno obj = repositorio.findOne(id);
		return obj;

	}

	public Aluno insert(Aluno obj) {
		obj.setId(null);		
		obj = repositorio.save(obj);
		return obj;
	}

	public Aluno update(Aluno obj) {
		Aluno aluno = find(obj.getId());
		return repositorio.save(aluno);
	}

	public void delete(Integer id) {
		find(id);
		repositorio.delete(id);

	}

	public List<Aluno> findAll() {
		return repositorio.findAll();
	}
	
	public Aluno fromDto(AlunoDTO dto) {
		Aluno al = new Aluno(dto.getId(), dto.getNome(), dto.getMatricula(), null,dto.getCr(),dto.getEstadoCivil());
		Curso curso = cursoRepositorio.findOne(dto.getCurso());
		al.setCurso(curso);
		return al;
	}

}
